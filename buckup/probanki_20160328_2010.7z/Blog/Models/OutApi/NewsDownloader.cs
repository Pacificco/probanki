﻿using Bankiru.Models.Domain.News;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading;
using System.Web;
using System.Xml;
using System.ServiceModel.Syndication;

namespace Bankiru.Models.OutApi
{
    public class NewsDownloader : IHttpModule
    {
        static Timer timer;
        long _interval = 300000; //30 секунд
        static object _synclock = new object();
        static string _lastError = "";        
        static int _counter = 0;
        static bool _isDownLoading = false;

        static DateTimeOffset _lastLoadDateTime_ria_economy = DateTimeOffset.Now.AddDays(-1);
        static DateTimeOffset _lastLoadDateTime_rambler_finance = DateTimeOffset.Now.AddDays(-1);
        static DateTimeOffset _lastLoadDateTime_kommersant_economics = DateTimeOffset.Now.AddDays(-1);
        static DateTimeOffset _lastLoadDateTime_vedomosti_finance = DateTimeOffset.Now.AddDays(-1);

        public void Init(HttpApplication app)
        {
            timer = new Timer(new TimerCallback(LoadNews), null, 0, _interval);
        }

        private void LoadNews(object obj)
        {
            _counter++;
            if (_isDownLoading) return;
            try
            {
                _isDownLoading = true;
                DateTimeOffset lastLoadDateTime = DateTimeOffset.Now;
                LoadRiaNews("http://ria.ru/export/rss2/economy/index.xml", "http://ria.ru", "РИА Новости", _lastLoadDateTime_ria_economy, ref lastLoadDateTime);
                _lastLoadDateTime_ria_economy = lastLoadDateTime;
                LoadRiaNews("http://finance.rambler.ru/xml/rambler_finance_news.xml", "http://finance.rambler.ru", "RNS", _lastLoadDateTime_rambler_finance, ref lastLoadDateTime);
                _lastLoadDateTime_rambler_finance = lastLoadDateTime;
                LoadRiaNews("http://www.kommersant.ru/RSS/section-economics.xml", "http://www.kommersant.ru", "Коммерсантъ", _lastLoadDateTime_kommersant_economics, ref lastLoadDateTime);
                _lastLoadDateTime_kommersant_economics = lastLoadDateTime;
                LoadRiaNews("http://www.vedomosti.ru/rss/rubric/finance", "http://www.vedomosti.ru", "Ведомости", _lastLoadDateTime_vedomosti_finance, ref lastLoadDateTime);
                _lastLoadDateTime_vedomosti_finance = lastLoadDateTime;
            }
            finally
            {
                _isDownLoading = false;
            }            
        }

        private void LoadRiaNews(string rss, string url, string author, DateTimeOffset lastLoadDateTime, ref DateTimeOffset newLastLoadDateTime)
        {
            newLastLoadDateTime = DateTimeOffset.Now;
            lock (_synclock)
            {
                try
                {
                    NewsManager manager = new NewsManager();
                    VM_News news = null;
                    using (XmlReader reader = XmlReader.Create(rss))
                    {
                        var formatter = new Rss20FeedFormatter();
                        formatter.ReadFrom(reader);
                        if (formatter.Feed.Items != null && formatter.Feed.Items.Count<SyndicationItem>() > 0)
                        {
                            foreach (SyndicationItem item in formatter.Feed.Items)
                            {
                                try
                                {
                                    if (item.PublishDate > lastLoadDateTime)
                                    {
                                        news = new VM_News()
                                        {
                                            IsActive = true,
                                            Title = item.Title.Text,
                                            NewsText = item.Summary.Text,
                                            PublishedAt = item.PublishDate.DateTime,
                                            MetaTitle = item.Title.Text,
                                            MetaDesc = item.Summary.Text.Length > 150 ? item.Summary.Text.Substring(0, 150) + "..." : item.Summary.Text,
                                            MetaNoFollow = false,
                                            MetaNoIndex = false,
                                            Author = author,
                                            NewsUrl = url                                            
                                        };
                                        if (!manager.CreateNews(ref news))
                                        {
                                            _lastError = manager.LastError;
                                        }
                                    }
                                }
                                catch
                                {
                                    //log
                                }
                            }
                        }
                        newLastLoadDateTime = (from i in formatter.Feed.Items select i.PublishDate).Max();                                                 
                    }                    
                }
                catch (WebException ex)
                {
                    _lastError = "Syndication Reader: " + ex.ToString();
                }
            }
        }

        public void Dispose()
        {
        
        }
    }

}