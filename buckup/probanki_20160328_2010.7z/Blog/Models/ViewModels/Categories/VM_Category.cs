﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Bankiru.Models.ViewModels
{
    /// <summary>
    /// Модель представления категории
    /// </summary>
    public class VM_Category
    {
        public int Id { set; get; }
        public string Name { set; get; }
        public string Alias { set; get; }
        public string Description { set; get; }
        public bool IsActive { set; get; }
        public int ArticlesCount { set; get; }
    }
}