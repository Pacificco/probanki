﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Bankiru.Models.ViewModels
{
    /// <summary>
    /// Модель представления статьи в списке (блог)
    /// </summary>
    public class ArticleListItemVModel
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Alias { get; set; }
        public string TextPrev { get; set; }
        public DateTime CreatedAt { get; set; }
        public string Author { get; set; }
        public int CommentsCount { get; set; }
        public int Hits { get; set; }
    }
}