﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Bankiru.Models.ViewModels.Articles
{
    public class MV_Article
    {
        [Display(Name="Id")]
        [HiddenInput]
        public int Id { get; set; }
        [Display(Name = "Заголовок")]
        public string Title { get; set; }
        [Display(Name = "Алиас")]
        public string Alias { get; set; }
        [Display(Name = "Текст для предварительного просмотра")]
        public string TextPrev { get; set; }
        [Display(Name = "Текст")]
        public string TextFull { get; set; }
    }
}