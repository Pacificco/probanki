﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Bankiru.Models.Helpers
{
    /// <summary>
    /// Логическое значение
    /// </summary>
    public enum BoolType
    {
        Empty,
        True,
        False
    }
}