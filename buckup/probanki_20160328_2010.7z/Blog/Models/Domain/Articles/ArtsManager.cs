﻿using Bankiru.Models.DataBase;
using Bankiru.Models.Domain.Categories;
using Bankiru.Models.Domain.Comments;
using Bankiru.Models.Domain.Other;
using Bankiru.Models.Infrastructure;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Bankiru.Models.Domain.Articles
{
    public class ArtsManager
    {
        public string LastError = "";

        //Список статей
        public VM_Articles GetArts(VM_ArtsFilters filter, int page = 1)
        {
            VM_Articles _arts = new VM_Articles();
            _arts.Filters.Assign(filter);
            _arts.PagingInfo.SetData(page, _getArtsTotalCount(filter));
            if (_arts.PagingInfo.TotalItems == -1) return null;
            _arts.PagingInfo.CurrentPage = page;
            _arts.Items = _getArts(filter, _arts.PagingInfo.GetNumberFrom(), _arts.PagingInfo.GetNumberTo());
            return _arts;
        }

        //Статья
        public VM_Article GetArt(int id)
        {
            string SQLQuery = _sqlGetArt(id);
            VM_Article art = new VM_Article();
            SqlCommand _command = null;
            SqlDataReader _reader = null;
            lock (GlobalParams._DBAccessLock)
            {
                try
                {
                    _command = new SqlCommand(SQLQuery, GlobalParams.GetConnection());
                    _reader = _command.ExecuteReader();
                    if (_reader == null)
                    {
                        LastError = "Ошибка во время загрузки статьи (id=\"" + id.ToString() + "\")!\nСервер вернул ответ NULL.";
                        return null;
                    }

                    if (_reader.HasRows)
                    {
                        if (_reader.Read())
                        {
                            art.Id = _reader.GetInt32(0);
                            art.Title = _reader.GetString(1);
                            art.Alias = _reader.GetString(2);
                            art.SubTitle = _reader.GetString(3);
                            art.TextPrev = _reader.GetString(4);
                            art.CategoryId = _reader.GetInt32(5);
                            art.IsActive = _reader.GetBoolean(6);
                            art.MetaTitle = _reader.GetString(7);
                            art.MetaKeys = _reader.GetString(8);
                            art.MetaDesc = _reader.GetString(9);
                            art.MetaNoIndex = _reader.GetBoolean(10);
                            art.MetaNoFollow = _reader.GetBoolean(11);
                            art.UpdatedAt = _reader.GetDateTime(12);
                            art.CreatedAt = _reader.GetDateTime(13);
                            art.UserId = _reader.GetInt32(14);
                            art.TextFull = _reader.GetString(15);
                            art.OtherUser = _reader.IsDBNull(16) ? "" : _reader.GetString(16);
                            art.PublishedAt = _reader.GetDateTime(17);
                            art.Hits = _reader.GetInt32(18);
                            art.IsCentral = _reader.GetBoolean(19);
                        }
                    }
                }
                catch (Exception ex)
                {
                    LastError = "Ошибка во время загрузки статьи (id=\"" + id.ToString() + "\")!\n" + ex.ToString();
                    return null;
                }
                finally
                {
                    if (_reader != null)
                    {
                        _reader.Close();
                        _reader.Dispose();
                    }
                    if (_command != null)
                    {
                        _command.Dispose();
                    }
                }
            }
            return art;
        }
        public VM_ArtItem GetArtItem(int id)
        {
            string SQLQuery = _sqlGetArtItem(id);
            VM_ArtItem art = new VM_ArtItem();
            SqlCommand _command = null;
            SqlDataReader _reader = null;
            lock (GlobalParams._DBAccessLock)
            {
                try
                {
                    _command = new SqlCommand(SQLQuery, GlobalParams.GetConnection());
                    _reader = _command.ExecuteReader();
                    if (_reader == null)
                    {
                        LastError = "Ошибка во время загрузки статьи (id=\"" + id.ToString() + "\")!\nСервер вернул ответ NULL.";
                        return null;
                    }
                    if (_reader.HasRows)
                    {
                        if (_reader.Read())
                        {
                            art.Id = _reader.GetInt32(0);
                            art.Alias = _reader.GetString(1);
                            art.Title = _reader.GetString(2);
                            art.CategoryId = _reader.GetInt32(3);
                            art.IsActive = _reader.GetBoolean(4);
                            art.Hits = _reader.GetInt32(5);
                            art.UserId = _reader.GetInt32(6);
                            art.OtherUser = _reader.IsDBNull(7) ? "" : _reader.GetString(7);
                            art.PublishedAt = _reader.GetDateTime(8);
                            art.CreatedAt = _reader.GetDateTime(9);

                            art.Category = _getCategoryName(art.CategoryId);
                        }
                    }
                }
                catch (Exception ex)
                {
                    LastError = "Ошибка во время загрузки статьи (id=\"" + id.ToString() + "\")!\n" + ex.ToString();
                    return null;
                }
                finally
                {
                    if (_reader != null)
                    {
                        _reader.Close();
                        _reader.Dispose();
                    }
                    if (_command != null)
                    {
                        _command.Dispose();
                    }
                }
            }
            return art;
        }
        public VM_ArtItem GetCentralArtItem()
        {
            string SQLQuery = _sqlGetCentralArticle();
            VM_ArtItem art = null;
            SqlCommand _command = null;
            SqlDataReader _reader = null;
            lock (GlobalParams._DBAccessLock)
            {
                try
                {
                    _command = new SqlCommand(SQLQuery, GlobalParams.GetConnection());
                    _reader = _command.ExecuteReader();
                    if (_reader == null)
                    {
                        LastError = "Ошибка во время загрузки центральной статьи!\nСервер вернул ответ NULL.";
                        return null;
                    }
                    if (_reader.HasRows)
                    {
                        if (_reader.Read())
                        {
                            art = new VM_ArtItem();
                            art.Id = _reader.GetInt32(0);
                            art.Alias = _reader.GetString(1);
                            art.Title = _reader.GetString(2);
                            art.CategoryId = _reader.GetInt32(3);
                            art.IsActive = _reader.GetBoolean(4);
                            art.Hits = _reader.GetInt32(5);
                            art.UserId = _reader.GetInt32(6);
                            art.OtherUser = _reader.IsDBNull(7) ? "" : _reader.GetString(7);
                            art.PublishedAt = _reader.GetDateTime(8);
                            art.TextPrev = _reader.GetString(9);
                            art.CreatedAt = _reader.GetDateTime(10);
                            art.SubTitle = _reader.GetString(11);
                            
                            art.Category = _getCategoryName(art.CategoryId);
                            if (String.IsNullOrEmpty(art.Category)) 
                                art.Category = "?";
                            art.CommentsInfo = new VM_ArtCommentInfo();
                        }
                    }
                }
                catch (Exception ex)
                {
                    LastError = "Ошибка во время загрузки центральной статьи!\n" + ex.ToString();
                    return null;
                }
                finally
                {
                    if (_reader != null)
                    {
                        _reader.Close();
                        _reader.Dispose();
                    }
                    if (_command != null)
                    {
                        _command.Dispose();
                    }
                }
            }
            if (art != null && art.Id > 0)
            {
                Dictionary<int, VM_ArtCommentInfo> artComments = _getArtsCommentsInfo(new int[] { art.Id });
                if (artComments != null && artComments.Count > 0)
                {
                    art.CommentsInfo.Assign(artComments.First().Value);
                }
            }
            return art;
        }
        public List<VM_ArtItem> GetArtItems()
        {
            string SQLQuery = _sqlGetArtItems();
            List<VM_ArtItem> arts = new List<VM_ArtItem>();
            SqlCommand _command = null;
            SqlDataReader _reader = null;
            lock (GlobalParams._DBAccessLock)
            {
                try
                {
                    _command = new SqlCommand(SQLQuery, GlobalParams.GetConnection());
                    _reader = _command.ExecuteReader();
                    if (_reader == null)
                    {
                        LastError = "Ошибка во время загрузки статей!\nСервер вернул ответ NULL.";
                        return null;
                    }
                    if (_reader.HasRows)
                    {
                        while (_reader.Read())
                        {
                            arts.Add(new VM_ArtItem()
                            {
                                Id = _reader.GetInt32(0),
                                Alias = _reader.GetString(1),
                                Title = _reader.GetString(2),
                                CategoryId = _reader.GetInt32(3),
                                IsActive = _reader.GetBoolean(4),
                                Hits = _reader.GetInt32(5),
                                UserId = _reader.GetInt32(6),
                                OtherUser = _reader.IsDBNull(7) ? "" : _reader.GetString(7),
                                PublishedAt = _reader.GetDateTime(8),
                                CreatedAt = _reader.GetDateTime(9),
                            });
                        }
                    }
                }
                catch (Exception ex)
                {
                    LastError = "Ошибка во время загрузки статей!\n" + ex.ToString();
                    return null;
                }
                finally
                {
                    if (_reader != null)
                    {
                        _reader.Close();
                        _reader.Dispose();
                    }
                    if (_command != null)
                    {
                        _command.Dispose();
                    }
                }
            }
            return arts;
        }
        public List<VM_Category> GetCategories()
        {
            string SQLQuery = _sqlGetCategories();
            List<VM_Category> cats = new List<VM_Category>();
            SqlCommand _command = null;
            SqlDataReader _reader = null;
            lock (GlobalParams._DBAccessLock)
            {
                try
                {
                    _command = new SqlCommand(SQLQuery, GlobalParams.GetConnection());
                    _reader = _command.ExecuteReader();
                    if (_reader == null)
                    {
                        LastError = "Ошибка во время загрузки категорий статей!\nСервер вернул ответ NULL.";
                        return null;
                    }

                    if (_reader.HasRows)
                    {
                        while (_reader.Read())
                        {
                            cats.Add(new VM_Category()
                            {
                                Id = _reader.GetInt32(0),
                                Alias = _reader.GetString(1),
                                Title = _reader.GetString(2)
                            });
                        }
                    }
                }
                catch (Exception ex)
                {
                    LastError = "Ошибка во время загрузки категорий статей!\n" + ex.ToString();
                    return null;
                }
                finally
                {
                    if (_reader != null)
                    {
                        _reader.Close();
                        _reader.Dispose();
                    }
                    if (_command != null)
                    {
                        _command.Dispose();
                    }
                }
            }
            return cats;
        }
        public bool CreateArt(ref VM_Article art)
        {
            //Формирование ссылки
            string alias = GenerateAlias(art.Title);
            if (String.IsNullOrEmpty(alias)) return false;
            art.Alias = alias;
            art.UserId = 2;
            art.PublishedAt = DateTime.Now;
            //Формирование запроса
            string SQLQuery = _sqlCreateArt(art);
            SqlCommand _command = null;
            lock (GlobalParams._DBAccessLock)
            {
                try
                {
                    _command = new SqlCommand(SQLQuery, GlobalParams.GetConnection());
                    object objId = _command.ExecuteScalar();
                    if (objId == null)
                    {
                        LastError = "Ошибка во время создания статьи!\nСервер вернул ответ NULL.";
                        return false;
                    }
                    //Новый Id
                    art.Id = Convert.ToInt32(objId.ToString());
                    return true;
                }
                catch (Exception ex)
                {
                    LastError = "Ошибка во время создания статьи!\n" + ex.ToString();
                    return false;
                }
                finally
                {
                    if (_command != null)
                    {
                        _command.Dispose();
                    }
                }
            }
        }
        public bool UpdateArt(int id, VM_Article art)
        {            
            //Формирование запроса
            art.PublishedAt = DateTime.Now;
            string SQLQuery = _sqlUpdateArt(id, art);
            SqlCommand _command = null;
            lock (GlobalParams._DBAccessLock)
            {
                try
                {
                    _command = new SqlCommand(SQLQuery, GlobalParams.GetConnection());
                    int i = _command.ExecuteNonQuery();
                    if (i < 0)
                    {
                        LastError = "Ошибка во время обновления статьи!\nСервер вернул ответ " + i.ToString() + ".";
                        return false;
                    }
                    return true;
                }
                catch (Exception ex)
                {
                    LastError = "Ошибка во время обновления статьи!\n" + ex.ToString();
                    return false;
                }
                finally
                {
                    if (_command != null)
                    {
                        _command.Dispose();
                    }
                }
            }
        }
        public bool DeleteArt(int id)
        {
            return true;
        }
        public bool SetArtActive(int id, bool action)
        {
            //Формирование запроса
            string SQLQuery = _sqlSetArtActive(id, action);
            SqlCommand _command = null;
            lock (GlobalParams._DBAccessLock)
            {
                try
                {
                    _command = new SqlCommand(SQLQuery, GlobalParams.GetConnection());
                    int i = _command.ExecuteNonQuery();
                    if (i < 0)
                    {
                        LastError = "Ошибка во время установки активности статьи!\nСервер вернул ответ " + i.ToString() + ".";
                        return false;
                    }
                    return true;
                }
                catch (Exception ex)
                {
                    LastError = "Ошибка во время установки активности статьи!\n" + ex.ToString();
                    return false;
                }
                finally
                {
                    if (_command != null)
                    {
                        _command.Dispose();
                    }
                }
            }
        }
        public bool SetArticleAsCentral(int id)
        {
            //Формирование запроса            
            if (DbStruct.BeginTransaction("SetArticleAsCentral"))
            {
                LastError = "Ошибка во время открытия транзакции";
                return false;
            }
            string SQLQuery = _sqlArticleAsCentral(id);
            bool success = true;            
            SqlCommand _command = null;
            lock (GlobalParams._DBAccessLock)
            {
                try
                {
                    _command = new SqlCommand(SQLQuery, GlobalParams.GetConnection());
                    int i = _command.ExecuteNonQuery();
                    if (i < 0)
                    {
                        LastError = "Ошибка во время установки центральной статьи!\nСервер вернул ответ " + i.ToString() + ".";
                        return false;
                    }
                    return true;
                }
                catch (Exception ex)
                {
                    LastError = "Ошибка во время установки центральной статьи!\n" + ex.ToString();
                    success = false;
                }
                finally
                {
                    if (_command != null)
                    {
                        _command.Dispose();
                    }
                }
            }
            if (success)
            {
                if (!DbStruct.CommitTransaction("SetArticleAsCentral"))
                {
                    LastError = "Ошибка во время закрытия транзакции!";
                    DbStruct.RollBackTransaction("SetArticleAsCentral");
                    return false;
                }
                return true;
            }
            else
            {
                DbStruct.RollBackTransaction("SetArticleAsCentral");
                return false;
            }
        }

        //Комментарии
        public VM_Comments GetLastComments(int categoryId, int rowCount)
        {
            VM_Comments _comments = new VM_Comments();
            _comments.Filters = new VM_CommentsFilters();
            _comments.Items = _getLastComments(categoryId, rowCount);
            return _comments;
        }
        private List<VM_CommentItem> _getLastComments(int categoryId, int rowCount)
        {
            string SQLQuery = _sqlGetLastComments(categoryId, rowCount);
            List<VM_CommentItem> items = new List<VM_CommentItem>();
            SqlCommand _command = null;
            SqlDataReader _reader = null;
            lock (GlobalParams._DBAccessLock)
            {
                try
                {
                    _command = new SqlCommand(SQLQuery, GlobalParams.GetConnection());
                    _reader = _command.ExecuteReader();
                    if (_reader == null)
                    {
                        LastError = "Ошибка во время загрузки последних комментариев!\nСервер вернул ответ NULL.";
                        return null;
                    }
                    if (_reader.HasRows)
                    {
                        VM_CommentItem comment = null;
                        while (_reader.Read())
                        {
                            comment = new VM_CommentItem();
                            comment.Id = _reader.GetInt32(0);
                            comment.CommentText = _reader.GetString(1);
                            comment.CreatedAt = _reader.GetDateTime(2);
                            comment.LikeCount = _reader.GetInt32(3);
                            comment.DisLikeCount = _reader.GetInt32(4);                            
                            items.Add(comment);
                        }
                    }
                }
                catch (Exception ex)
                {
                    LastError = "Ошибка во время загрузки последних комментариев!\n" + ex.ToString();
                    return null;
                }
                finally
                {
                    if (_reader != null)
                    {
                        _reader.Close();
                        _reader.Dispose();
                    }
                    if (_command != null)
                    {
                        _command.Dispose();
                    }
                }
            }
            return items;
        }

        #region ВНУТРЕННИЕ МЕТОДЫ
        //Поиск статей
        private int _getArtsTotalCount(VM_ArtsFilters filter)
        {
            string SQLQuery = _sqlGetArtsTotalCount(filter);
            SqlCommand _command = null;
            lock (GlobalParams._DBAccessLock)
            {
                try
                {
                    _command = new SqlCommand(SQLQuery, GlobalParams.GetConnection());
                    object count = _command.ExecuteScalar();
                    if (count == null)
                    {
                        LastError = "Ошибка во время определения общего числа статей!\nСервер вернул ответ NULL.";
                        return -1;
                    }
                    return (int)count;
                }
                catch (Exception ex)
                {
                    LastError = "Ошибка во время определения общего числа статей!\n" + ex.ToString();
                    return -1;
                }
                finally
                {
                    if (_command != null)
                    {
                        _command.Dispose();
                    }
                }
            }
        }
        private string _sqlGetArtsTotalCount(VM_ArtsFilters filter)
        {
            string SqlConds = _sqlGetFilter(filter);
            string SqlQuery = String.Empty;
            SqlQuery += DbStruct.SE.SELECT + " ";
            SqlQuery += DbStruct.SE.COUNT + "(*)";
            SqlQuery += " " + DbStruct.SE.FROM + " ";
            SqlQuery += DbStruct.Articles.TABLENAME;
            if (!String.IsNullOrEmpty(SqlConds))
            {
                SqlQuery += " " + DbStruct.SE.WHERE + " ";
                SqlQuery += SqlConds;
            }
            SqlQuery += ";";
            return SqlQuery;
        }
        private List<VM_ArtItem> _getArts(VM_ArtsFilters filter, int offset, int limit)
        {
            string SQLQuery = _sqlGetArts(filter, offset, limit);
            List<VM_ArtItem> items = new List<VM_ArtItem>();
            SqlCommand _command = null;
            SqlDataReader _reader = null;
            lock (GlobalParams._DBAccessLock)
            {
                try
                {
                    _command = new SqlCommand(SQLQuery, GlobalParams.GetConnection());
                    _reader = _command.ExecuteReader();
                    if (_reader == null)
                    {
                        LastError = "Ошибка во время загрузки статей!\nСервер вернул ответ NULL.";
                        return null;
                    }
                    if (_reader.HasRows)
                    {
                        VM_ArtItem art = null;
                        while (_reader.Read())
                        {
                            art = new VM_ArtItem();
                            art.Id = _reader.GetInt32(1);
                            art.Alias = _reader.GetString(2);
                            art.Title = _reader.GetString(3);
                            art.CategoryId = _reader.GetInt32(4);
                            if (art.CategoryId > 0)
                            {
                                art.Category = _getCategoryName(art.CategoryId);
                            }
                            art.IsActive = _reader.GetBoolean(5);
                            art.Hits = _reader.GetInt32(6);
                            art.UserId = _reader.GetInt32(7);
                            art.OtherUser = _reader.IsDBNull(8) ? "" : _reader.GetString(8);
                            art.PublishedAt = _reader.GetDateTime(9);
                            art.CreatedAt = _reader.GetDateTime(10);
                            art.CommentsInfo = new VM_ArtCommentInfo();
                            items.Add(art);
                        }
                    }
                }
                catch (Exception ex)
                {
                    LastError = "Ошибка во время загрузки статей!\n" + ex.ToString();
                    return null;
                }
                finally
                {
                    if (_reader != null)
                    {
                        _reader.Close();
                        _reader.Dispose();
                    }
                    if (_command != null)
                    {
                        _command.Dispose();
                    }
                }
            }
            if (items.Count > 0)
            {
                int[] artsIds = (from i in items                                   
                                   select i.Id).Distinct().ToArray<int>();
                if (artsIds != null && artsIds.Length > 0)
                {
                    Dictionary<int, VM_ArtCommentInfo> artComments = _getArtsCommentsInfo(artsIds);
                    if (artComments != null && artComments.Count > 0)
                    {
                        VM_ArtItem item = null;
                        foreach (var cInfo in artComments)
                        {
                            item = items.FirstOrDefault(i => i.Id == cInfo.Key);
                            if (item != null)
                                item.CommentsInfo.Assign(cInfo.Value);
                        }
                    }
                }
            }
            return items;
        }
        private List<VM_ArtItem> _getArts(int[] ids)
        {
            string SQLQuery = _sqlGetArts(ids);
            List<VM_ArtItem> items = new List<VM_ArtItem>();
            SqlCommand _command = null;
            SqlDataReader _reader = null;
            lock (GlobalParams._DBAccessLock)
            {
                try
                {
                    _command = new SqlCommand(SQLQuery, GlobalParams.GetConnection());
                    _reader = _command.ExecuteReader();
                    if (_reader == null)
                    {
                        LastError = "Ошибка во время загрузки статей!\nСервер вернул ответ NULL.";
                        return null;
                    }
                    if (_reader.HasRows)
                    {
                        VM_ArtItem art = null;
                        while (_reader.Read())
                        {
                            art = new VM_ArtItem();
                            art.Id = _reader.GetInt32(0);
                            art.Alias = _reader.GetString(1);
                            art.Title = _reader.GetString(2);
                            art.CategoryId = _reader.GetInt32(3);
                            art.IsActive = _reader.GetBoolean(4);
                            art.Hits = _reader.GetInt32(5);
                            art.UserId = _reader.GetInt32(6);
                            art.OtherUser = _reader.IsDBNull(7) ? "" : _reader.GetString(7);
                            art.PublishedAt = _reader.GetDateTime(8);
                            art.CreatedAt = _reader.GetDateTime(9);
                            items.Add(art);
                        }
                    }
                }
                catch (Exception ex)
                {
                    LastError = "Ошибка во время загрузки статей!\n" + ex.ToString();
                    return null;
                }
                finally
                {
                    if (_reader != null)
                    {
                        _reader.Close();
                        _reader.Dispose();
                    }
                    if (_command != null)
                    {
                        _command.Dispose();
                    }
                }
            }
            return items;
        }
        private Dictionary<int, VM_ArtCommentInfo> _getArtsCommentsInfo(int[] ids)
        {
            Dictionary<int, VM_ArtCommentInfo> result = new Dictionary<int, VM_ArtCommentInfo>();
            string SQLQuery = _sqlGetArtsCommentsInfo(ids);
            SqlCommand _command = null;
            SqlDataReader _reader = null;
            lock (GlobalParams._DBAccessLock)
            {
                try
                {
                    _command = new SqlCommand(SQLQuery, GlobalParams.GetConnection());
                    _reader = _command.ExecuteReader();
                    if (_reader != null && _reader.HasRows)
                    {
                        while (_reader.Read())
                        {
                            result.Add(
                                _reader.GetInt32(0), 
                                new VM_ArtCommentInfo() 
                                {
                                    CommentsCount = _reader.GetInt32(1),
                                    LikesCount = _reader.GetInt32(2),
                                    DisLikesCount = _reader.GetInt32(3)
                                });    
                        }
                        
                    }
                    return result;
                }
                catch (Exception ex)
                {
                    LastError = "Ошибка во время получения информации о комментариях для статей!\n" + ex.ToString();
                    return null;
                }
                finally
                {
                    if (_reader != null)
                    {
                        _reader.Close();
                        _reader.Dispose();
                    }
                    if (_command != null)
                    {
                        _command.Dispose();
                    }
                }
            }
        }
        private bool _dbAliasExists(string alias)
        {
            string SQLQuery = _sqlGetAliasExists(alias);
            SqlCommand _command = null;
            SqlDataReader _reader = null;
            lock (GlobalParams._DBAccessLock)
            {
                try
                {
                    _command = new SqlCommand(SQLQuery, GlobalParams.GetConnection());
                    _reader = _command.ExecuteReader();
                    if (_reader != null && _reader.HasRows)
                        return true;
                    return false;
                }
                catch (Exception ex)
                {
                    LastError = "Ошибка во время проверки ссылки на существование!\n" + ex.ToString();
                    return false;
                }
                finally
                {
                    if (_reader != null)
                    {
                        _reader.Close();
                        _reader.Dispose();
                    }
                    if (_command != null)
                    {
                        _command.Dispose();
                    }
                }
            }
        }

        //Sql
        //Публикации
        private string _sqlGetArts(VM_ArtsFilters filter, int offset, int limit)
        {
            string SqlConds = _sqlGetFilter(filter);
            string SqlQuery = String.Empty;
            SqlQuery += DbStruct.SE.SELECT + " t1.* " + DbStruct.SE.FROM + "(";
            SqlQuery += DbStruct.SE.SELECT + " ROW_NUMBER() OVER(";
            SqlQuery += DbStruct.SE.ORDER_BY + " ";
            SqlQuery += DbStruct.Articles.FIELDS.CreatedAt;
            SqlQuery += " " + DbStruct.SE.DESC;
            SqlQuery += ") AS RowNumber, ";
            SqlQuery += DbStruct.Articles.FIELDS.Id + ",";
            SqlQuery += DbStruct.Articles.FIELDS.Alias + ",";
            SqlQuery += DbStruct.Articles.FIELDS.Title + ",";
            SqlQuery += DbStruct.Articles.FIELDS.CategoryId + ",";
            SqlQuery += DbStruct.Articles.FIELDS.IsActive + ",";            
            SqlQuery += DbStruct.Articles.FIELDS.Hits + ",";
            SqlQuery += DbStruct.Articles.FIELDS.UserId + ",";
            SqlQuery += DbStruct.Articles.FIELDS.OtherUser + ",";
            SqlQuery += DbStruct.Articles.FIELDS.PublishedAt + ",";
            SqlQuery += DbStruct.Articles.FIELDS.CreatedAt;
            SqlQuery += " " + DbStruct.SE.FROM + " ";
            SqlQuery += DbStruct.Articles.TABLENAME;
            if (!String.IsNullOrEmpty(SqlConds))
            {
                SqlQuery += " " + DbStruct.SE.WHERE + " ";
                SqlQuery += SqlConds;
            }
            SqlQuery += ") AS t1";
            SqlQuery += " " + DbStruct.SE.WHERE + " ";
            SqlQuery += "t1.RowNumber BETWEEN {0} AND {1}";
            SqlQuery += ";";
            return String.Format(SqlQuery, offset.ToString(), limit.ToString());
        }
        private string _sqlGetFilter(VM_ArtsFilters filter)
        {
            string SqlConds = String.Empty;
            if (filter.IsActive != EnumBoolType.None)
            {
                SqlConds += " " + DbStruct.SE.AND + " ";
                SqlConds += DbStruct.Articles.FIELDS.IsActive;
                if (filter.IsActive == EnumBoolType.True)
                    SqlConds += " = 1";
                else
                    SqlConds += " = 0";
            }
            if (!String.IsNullOrEmpty(filter.Title))
            {
                SqlConds += " " + DbStruct.SE.AND + " ";
                SqlConds += DbStruct.Articles.FIELDS.Title;
                SqlConds += " " + DbStruct.SE.LIKE + " ";
                SqlConds += "'%" + DbStruct.SQLRealEscapeString(filter.Title) + "%'";
            }
            if (filter.CategoryId > 0)
            {
                SqlConds += " " + DbStruct.SE.AND + " ";
                SqlConds += DbStruct.Articles.FIELDS.CategoryId;
                SqlConds += " = " + filter.CategoryId.ToString();
            }            
            return String.IsNullOrEmpty(SqlConds) ? String.Empty : SqlConds.Substring(5);
        }
        private string _sqlGetArtsCommentsInfo(int[] ids)
        {
            if (ids.Length == 0) return String.Empty;
            string strIds = String.Empty;
            foreach (int id in ids)
                strIds += "," + id.ToString();
            strIds = strIds.Substring(1);
            string SqlQuery = String.Empty;
            SqlQuery += DbStruct.SE.SELECT + " ";
            SqlQuery += DbStruct.Articles.ALIAS + "." + DbStruct.Articles.FIELDS.Id + ",";
            SqlQuery += DbStruct.SE.COUNT + "(";
            SqlQuery += DbStruct.Comments.ALIAS + "." + DbStruct.Comments.FIELDS.Id;
            SqlQuery += "),";
            SqlQuery += DbStruct.SE.SUM + "(";
            SqlQuery += DbStruct.Comments.ALIAS + "." + DbStruct.Comments.FIELDS.LikeCount;
            SqlQuery += "),";
            SqlQuery += DbStruct.SE.SUM + "(";
            SqlQuery += DbStruct.Comments.ALIAS + "." + DbStruct.Comments.FIELDS.DisLikeCount;
            SqlQuery += ")";
            SqlQuery += " " + DbStruct.SE.FROM + " ";
            SqlQuery += DbStruct.Articles.TABLENAME + " " + DbStruct.Articles.ALIAS;
            SqlQuery += " " + DbStruct.SE.JOIN + " ";
            SqlQuery += DbStruct.Comments.TABLENAME + " " + DbStruct.Comments.ALIAS;
            SqlQuery += " " + DbStruct.SE.ON + " ";
            SqlQuery += DbStruct.Articles.ALIAS + "." + DbStruct.Articles.FIELDS.Id;
            SqlQuery += " = ";
            SqlQuery += DbStruct.Comments.ALIAS + "." + DbStruct.Comments.FIELDS.ArticleId;
            SqlQuery += " " + DbStruct.SE.WHERE + " ";
            SqlQuery += DbStruct.Articles.ALIAS + "." + DbStruct.Articles.FIELDS.Id;
            SqlQuery += " " + DbStruct.SE.IN + "(" + strIds + ")";
            SqlQuery += " " + DbStruct.SE.GROUP_BY + " ";
            SqlQuery += DbStruct.Articles.ALIAS + "." + DbStruct.Articles.FIELDS.Id;
            SqlQuery += ";";
            return SqlQuery;
        }
        private string _sqlGetArts(int[] ids)
        {
            if (ids.Length == 0) return String.Empty;
            string strIds = String.Empty;
            foreach (int id in ids)
                strIds += "," + id.ToString();
            strIds = strIds.Substring(1);
            string SqlQuery = String.Empty;
            SqlQuery += DbStruct.SE.SELECT + " ";
            SqlQuery += DbStruct.Articles.FIELDS.Id + ",";
            SqlQuery += DbStruct.Articles.FIELDS.Alias + ",";
            SqlQuery += DbStruct.Articles.FIELDS.Title + ",";
            SqlQuery += DbStruct.Articles.FIELDS.CategoryId + ",";
            SqlQuery += DbStruct.Articles.FIELDS.IsActive + ",";
            SqlQuery += DbStruct.Articles.FIELDS.Hits + ",";
            SqlQuery += DbStruct.Articles.FIELDS.UserId + ",";
            SqlQuery += DbStruct.Articles.FIELDS.OtherUser + ",";
            SqlQuery += DbStruct.Articles.FIELDS.PublishedAt;
            SqlQuery += " " + DbStruct.SE.FROM + " ";
            SqlQuery += DbStruct.Articles.TABLENAME;
            SqlQuery += " " + DbStruct.SE.WHERE + " ";
            SqlQuery += DbStruct.Articles.FIELDS.Id;
            SqlQuery += " " + DbStruct.SE.IN + "(" + strIds + ")";
            SqlQuery += " " + DbStruct.SE.ORDER_BY + " ";
            SqlQuery += DbStruct.Articles.FIELDS.CreatedAt;
            SqlQuery += " " + DbStruct.SE.DESC;
            SqlQuery += ";";
            return SqlQuery;
        }
        private string _sqlGetArt(int id)
        {
            string SqlQuery = String.Empty;
            SqlQuery += DbStruct.SE.SELECT + " *";
            SqlQuery += " " + DbStruct.SE.FROM + " ";
            SqlQuery += DbStruct.Articles.TABLENAME;
            SqlQuery += " " + DbStruct.SE.WHERE + " ";
            SqlQuery += DbStruct.Articles.FIELDS.Id;
            SqlQuery += " = " + id.ToString();
            SqlQuery += ";";
            return SqlQuery;
        }
        private string _sqlGetArtItem(int id)
        {
            string SqlQuery = String.Empty;
            SqlQuery += DbStruct.SE.SELECT + " ";
            SqlQuery += DbStruct.Articles.FIELDS.Id + ",";
            SqlQuery += DbStruct.Articles.FIELDS.Alias + ",";
            SqlQuery += DbStruct.Articles.FIELDS.Title + ",";
            SqlQuery += DbStruct.Articles.FIELDS.CategoryId + ",";
            SqlQuery += DbStruct.Articles.FIELDS.IsActive + ",";
            SqlQuery += DbStruct.Articles.FIELDS.Hits + ",";
            SqlQuery += DbStruct.Articles.FIELDS.UserId + ",";
            SqlQuery += DbStruct.Articles.FIELDS.OtherUser + ",";
            SqlQuery += DbStruct.Articles.FIELDS.PublishedAt;
            SqlQuery += " " + DbStruct.SE.FROM + " ";
            SqlQuery += DbStruct.Articles.TABLENAME;
            SqlQuery += " " + DbStruct.SE.WHERE + " ";
            SqlQuery += DbStruct.Articles.FIELDS.Id;
            SqlQuery += " = " + id.ToString();
            SqlQuery += ";";
            return SqlQuery;
        }
        private string _sqlGetCentralArticle()
        {
            string SqlQuery = String.Empty;
            SqlQuery += DbStruct.SE.SELECT + " ";
            SqlQuery += DbStruct.Articles.FIELDS.Id + ",";
            SqlQuery += DbStruct.Articles.FIELDS.Alias + ",";
            SqlQuery += DbStruct.Articles.FIELDS.Title + ",";
            SqlQuery += DbStruct.Articles.FIELDS.CategoryId + ",";
            SqlQuery += DbStruct.Articles.FIELDS.IsActive + ",";
            SqlQuery += DbStruct.Articles.FIELDS.Hits + ",";
            SqlQuery += DbStruct.Articles.FIELDS.UserId + ",";
            SqlQuery += DbStruct.Articles.FIELDS.OtherUser + ",";
            SqlQuery += DbStruct.Articles.FIELDS.PublishedAt + ",";
            SqlQuery += DbStruct.Articles.FIELDS.TextPrev + ",";
            SqlQuery += DbStruct.Articles.FIELDS.CreatedAt + ",";
            SqlQuery += DbStruct.Articles.FIELDS.SubTitle;
            SqlQuery += " " + DbStruct.SE.FROM + " ";
            SqlQuery += DbStruct.Articles.TABLENAME;
            SqlQuery += " " + DbStruct.SE.WHERE + " ";
            SqlQuery += DbStruct.Articles.FIELDS.IsCentral;
            SqlQuery += " = 1";
            SqlQuery += ";";
            return SqlQuery;
        }
        private string _sqlGetArtItems()
        {
            string SqlQuery = String.Empty;
            SqlQuery += DbStruct.SE.SELECT + " ";
            SqlQuery += DbStruct.Articles.FIELDS.Id + ",";
            SqlQuery += DbStruct.Articles.FIELDS.Alias + ",";
            SqlQuery += DbStruct.Articles.FIELDS.Title + ",";
            SqlQuery += DbStruct.Articles.FIELDS.CategoryId + ",";
            SqlQuery += DbStruct.Articles.FIELDS.IsActive + ",";
            SqlQuery += DbStruct.Articles.FIELDS.Hits + ",";
            SqlQuery += DbStruct.Articles.FIELDS.UserId + ",";
            SqlQuery += DbStruct.Articles.FIELDS.OtherUser + ",";
            SqlQuery += DbStruct.Articles.FIELDS.PublishedAt;
            SqlQuery += " " + DbStruct.SE.FROM + " ";
            SqlQuery += DbStruct.Articles.TABLENAME;
            SqlQuery += " " + DbStruct.SE.ORDER_BY + " ";
            SqlQuery += DbStruct.Articles.FIELDS.Title;
            SqlQuery += ";";
            return SqlQuery;
        }
        private string _sqlCreateArt(VM_Article art)
        {
            string SqlQuery = String.Empty;
            SqlQuery += DbStruct.SE.INSERT + " ";
            SqlQuery += DbStruct.Articles.TABLENAME;
            SqlQuery += "(";
            //SqlQuery += DbStruct.Articles.FIELDS.Id + ",";
            SqlQuery += DbStruct.Articles.FIELDS.Title + ",";
            SqlQuery += DbStruct.Articles.FIELDS.Alias + ",";
            SqlQuery += DbStruct.Articles.FIELDS.SubTitle + ",";
            SqlQuery += DbStruct.Articles.FIELDS.TextPrev + ",";
            SqlQuery += DbStruct.Articles.FIELDS.CategoryId + ",";
            SqlQuery += DbStruct.Articles.FIELDS.IsActive + ",";
            SqlQuery += DbStruct.Articles.FIELDS.IsCentral + ",";
            SqlQuery += DbStruct.Articles.FIELDS.MetaTitle + ",";
            SqlQuery += DbStruct.Articles.FIELDS.MetaKeys + ",";
            SqlQuery += DbStruct.Articles.FIELDS.MetaDesc + ",";
            SqlQuery += DbStruct.Articles.FIELDS.MetaNoIndex + ",";
            SqlQuery += DbStruct.Articles.FIELDS.MetaNoFollow + ",";
            SqlQuery += DbStruct.Articles.FIELDS.ChangedAt + ",";
            SqlQuery += DbStruct.Articles.FIELDS.CreatedAt + ",";
            SqlQuery += DbStruct.Articles.FIELDS.UserId + ",";
            SqlQuery += DbStruct.Articles.FIELDS.TextFull + ",";
            SqlQuery += DbStruct.Articles.FIELDS.OtherUser + ",";
            SqlQuery += DbStruct.Articles.FIELDS.PublishedAt + ",";
            SqlQuery += DbStruct.Articles.FIELDS.Hits;
            SqlQuery += ")";
            SqlQuery += " " + DbStruct.SE.VALUES + "(";
            SqlQuery += "'" + DbStruct.SQLRealEscapeString(art.Title) + "',";
            SqlQuery += "'" + DbStruct.SQLRealEscapeString(art.Alias) + "',";            
            SqlQuery += "'" + DbStruct.SQLRealEscapeString(art.SubTitle) + "',";
            SqlQuery += "'" + DbStruct.SQLRealEscapeString(art.TextPrev) + "',";
            SqlQuery += art.CategoryId.ToString() + ",";
            SqlQuery += art.IsActive ? "1," : "0,";
            SqlQuery += art.IsCentral ? "1," : "0,";
            SqlQuery += "'" + DbStruct.SQLRealEscapeString(art.MetaTitle) + "',";
            SqlQuery += "'" + DbStruct.SQLRealEscapeString(art.MetaKeys) + "',";
            SqlQuery += "'" + DbStruct.SQLRealEscapeString(art.MetaDesc) + "',";
            SqlQuery += art.MetaNoFollow ? "1," : "0,";
            SqlQuery += art.MetaNoIndex ? "1," : "0,";
            SqlQuery += DbStruct.SE.GETDATE + ",";
            SqlQuery += DbStruct.SE.GETDATE + ",";
            SqlQuery += art.UserId.ToString() + ",";            
            SqlQuery += "'" + DbStruct.SQLRealEscapeString(art.TextFull) + "',";            
            SqlQuery += (String.IsNullOrEmpty(art.OtherUser) ? DbStruct.SE.NULL :
                "'" + DbStruct.SQLRealEscapeString(art.OtherUser) + "'") + ",";
            SqlQuery += DbStruct.FormatSQLDateTime(art.PublishedAt, SQLDateTimeFormat.sdfDateTime) + ",";
            SqlQuery += art.Hits.ToString();            
            SqlQuery += ")";
            SqlQuery += ";";
            SqlQuery += DbStruct.SE.SELECT_SCOPE_IDENTITY;
            return SqlQuery;
        }
        private string _sqlUpdateArt(int id, VM_Article art)
        {
            string SqlQuery = String.Empty;
            SqlQuery += DbStruct.SE.UPDATE + " ";
            SqlQuery += DbStruct.Articles.TABLENAME;
            SqlQuery += " " + DbStruct.SE.SET + " ";            
            SqlQuery += DbStruct.Articles.FIELDS.Title + " = ";
            SqlQuery += "'" + DbStruct.SQLRealEscapeString(art.Title) + "',";            
            SqlQuery += DbStruct.Articles.FIELDS.SubTitle + " = ";
            SqlQuery += "'" + DbStruct.SQLRealEscapeString(art.SubTitle) + "',";
            SqlQuery += DbStruct.Articles.FIELDS.TextPrev + " = ";
            SqlQuery += "'" + DbStruct.SQLRealEscapeString(art.TextPrev) + "',";
            SqlQuery += DbStruct.Articles.FIELDS.CategoryId + " = ";
            SqlQuery += art.CategoryId.ToString() + ",";
            SqlQuery += DbStruct.Articles.FIELDS.IsActive + " = ";
            SqlQuery += art.IsActive ? "1," : "0,";
            SqlQuery += DbStruct.Articles.FIELDS.IsCentral + " = ";
            SqlQuery += art.IsCentral ? "1," : "0,";
            SqlQuery += DbStruct.Articles.FIELDS.MetaTitle + " = ";
            SqlQuery += "'" + DbStruct.SQLRealEscapeString(art.MetaTitle) + "',";
            SqlQuery += DbStruct.Articles.FIELDS.MetaKeys + " = ";
            SqlQuery += "'" + DbStruct.SQLRealEscapeString(art.MetaKeys) + "',";
            SqlQuery += DbStruct.Articles.FIELDS.MetaDesc + " = ";
            SqlQuery += "'" + DbStruct.SQLRealEscapeString(art.MetaDesc) + "',";
            SqlQuery += DbStruct.Articles.FIELDS.MetaNoIndex + " = ";
            SqlQuery += art.MetaNoFollow ? "1," : "0,";
            SqlQuery += DbStruct.Articles.FIELDS.MetaNoFollow + " = ";
            SqlQuery += art.MetaNoIndex ? "1," : "0,";
            SqlQuery += DbStruct.Articles.FIELDS.ChangedAt + " = ";
            SqlQuery += DbStruct.SE.GETDATE + ",";            
            //SqlQuery += DbStruct.Articles.FIELDS.UserId + " = ";
            //SqlQuery += art.UserId.ToString() + ",";
            SqlQuery += DbStruct.Articles.FIELDS.TextFull + " = ";
            SqlQuery += "'" + DbStruct.SQLRealEscapeString(art.TextFull) + "',";
            SqlQuery += DbStruct.Articles.FIELDS.OtherUser + " = ";
            SqlQuery += (String.IsNullOrEmpty(art.OtherUser) ? DbStruct.SE.NULL :
                "'" + DbStruct.SQLRealEscapeString(art.OtherUser) + "'") + ",";
            SqlQuery += DbStruct.Articles.FIELDS.PublishedAt + " = ";
            SqlQuery += DbStruct.FormatSQLDateTime(art.PublishedAt, SQLDateTimeFormat.sdfDateTime) + ",";
            SqlQuery += DbStruct.Articles.FIELDS.Hits + " = ";
            SqlQuery += art.Hits.ToString();            
            SqlQuery += " " + DbStruct.SE.WHERE + " ";
            SqlQuery += DbStruct.Articles.FIELDS.Id + " = " + id.ToString();
            SqlQuery += ";";
            return SqlQuery;
        }
        private string _sqlDeleteArt(int id)
        {
            string SqlQuery = String.Empty;
            SqlQuery += DbStruct.SE.DELETE + " ";
            SqlQuery += DbStruct.Articles.TABLENAME;
            SqlQuery += " " + DbStruct.SE.WHERE + " ";
            SqlQuery += DbStruct.Articles.FIELDS.Id;
            SqlQuery += " = " + id.ToString();
            SqlQuery += ";";
            return SqlQuery;
        }        
        private string _sqlSetArtActive(int id, bool action)
        {
            string SqlQuery = String.Empty;
            SqlQuery += DbStruct.SE.UPDATE + " ";
            SqlQuery += DbStruct.Articles.TABLENAME;
            SqlQuery += " " + DbStruct.SE.SET + " ";
            SqlQuery += DbStruct.Articles.FIELDS.IsActive + " = ";
            SqlQuery += action ? "1" : "0";
            SqlQuery += " " + DbStruct.SE.WHERE + " ";
            SqlQuery += DbStruct.Articles.FIELDS.Id + " = " + id.ToString();
            SqlQuery += ";";
            return SqlQuery;
        }
        private string _sqlArticleAsCentral(int id)
        {
            string SqlQuery = String.Empty;
            SqlQuery += DbStruct.SE.UPDATE + " ";
            SqlQuery += DbStruct.Articles.TABLENAME;
            SqlQuery += " " + DbStruct.SE.SET + " ";
            SqlQuery += DbStruct.Articles.FIELDS.IsCentral + " = 0";
            SqlQuery += " " + DbStruct.SE.WHERE + " ";
            SqlQuery += DbStruct.Articles.FIELDS.IsCentral + " = 1";
            SqlQuery += ";";
            SqlQuery += DbStruct.SE.UPDATE + " ";
            SqlQuery += DbStruct.Articles.TABLENAME;
            SqlQuery += " " + DbStruct.SE.SET + " ";
            SqlQuery += DbStruct.Articles.FIELDS.IsCentral + " = 1";
            SqlQuery += " " + DbStruct.SE.WHERE + " ";
            SqlQuery += DbStruct.Articles.FIELDS.Id + " = " + id.ToString();
            SqlQuery += ";";
            return SqlQuery;
        }
        private string _sqlGetAliasExists(string alias)
        {
            string SqlQuery = String.Empty;
            SqlQuery += DbStruct.SE.SELECT + " ";
            SqlQuery += DbStruct.Articles.FIELDS.Alias;
            SqlQuery += " " + DbStruct.SE.FROM + " ";
            SqlQuery += DbStruct.Articles.TABLENAME;
            SqlQuery += " " + DbStruct.SE.WHERE + " ";
            SqlQuery += DbStruct.Articles.FIELDS.Alias;
            SqlQuery += " = '" + DbStruct.SQLRealEscapeString(alias) + "'";
            SqlQuery += ";";
            return SqlQuery;
        }
        //Комментарии
        private string _sqlGetLastComments(int categoryId, int rowCount)
        {
            string SqlQuery = String.Empty;
            SqlQuery += DbStruct.SE.SELECT + " ";
            SqlQuery += DbStruct.SE.TOP + " " + rowCount.ToString() + " ";
            SqlQuery += DbStruct.Comments.FIELDS.Id + ",";
            SqlQuery += DbStruct.Comments.FIELDS.Text + ",";
            SqlQuery += DbStruct.Comments.FIELDS.CreatedAt + ",";
            SqlQuery += DbStruct.Comments.FIELDS.LikeCount + ",";
            SqlQuery += DbStruct.Comments.FIELDS.DisLikeCount;            
            SqlQuery += " " + DbStruct.SE.FROM + " ";
            SqlQuery += DbStruct.Comments.TABLENAME;
            SqlQuery += " " + DbStruct.SE.WHERE + " ";
            SqlQuery += DbStruct.Comments.FIELDS.Confirmed;
            SqlQuery += " = 1";
            SqlQuery += " " + DbStruct.SE.AND + " ";
            SqlQuery += DbStruct.Comments.FIELDS.IsActive;
            SqlQuery += " = 1";
            if (categoryId > 0)
            {
                SqlQuery += " " + DbStruct.SE.AND + " ";
                SqlQuery += DbStruct.Comments.FIELDS.ArticleId;
                SqlQuery += " " + DbStruct.SE.IN + " (";
                SqlQuery += DbStruct.SE.SELECT + " ";                
                SqlQuery += DbStruct.Articles.FIELDS.Id;
                SqlQuery += " " + DbStruct.SE.FROM + " ";
                SqlQuery += DbStruct.Articles.TABLENAME;
                SqlQuery += " " + DbStruct.SE.WHERE + " ";
                SqlQuery += DbStruct.Articles.FIELDS.IsActive;
                SqlQuery += " = 1";
                SqlQuery += " " + DbStruct.SE.AND + " ";
                SqlQuery += DbStruct.Articles.FIELDS.CategoryId;
                SqlQuery += categoryId.ToString();
                SqlQuery += ")";
            }
            SqlQuery += " " + DbStruct.SE.ORDER_BY + " ";
            SqlQuery += DbStruct.Comments.FIELDS.CreatedAt;
            SqlQuery += " " + DbStruct.SE.DESC;
            SqlQuery += ";";
            return SqlQuery;
        }        
        //Категории
        private string _sqlGetCategories()
        {
            string SqlQuery = String.Empty;
            SqlQuery += DbStruct.SE.SELECT + " ";
            SqlQuery += DbStruct.Categories.FIELDS.Id + ",";
            SqlQuery += DbStruct.Categories.FIELDS.Alias + ",";
            SqlQuery += DbStruct.Categories.FIELDS.Title;
            SqlQuery += " " + DbStruct.SE.FROM + " ";
            SqlQuery += DbStruct.Categories.TABLENAME;
            SqlQuery += " " + DbStruct.SE.WHERE + " ";
            SqlQuery += DbStruct.Categories.FIELDS.IsActive + " = 1";
            SqlQuery += " " + DbStruct.SE.ORDER_BY + " ";
            SqlQuery += DbStruct.Categories.FIELDS.Id;
            SqlQuery += ";";
            return SqlQuery;
        }
        
        //Дополнительно
        protected string GenerateAlias(string title)
        {
            string result = String.Empty;
            try
            {
                result = TransliterationManager.Front(title.Replace("- ", "-").Replace(" -", "-"));
                if (_dbAliasExists(result))
                {
                    string res = result;
                    int i = 1;
                    do
                    {
                        res = result + "-" + i.ToString();
                        i++;
                    }
                    while (_dbAliasExists(res));
                    result = res;
                }
                return result;
            }
            catch (Exception ex)
            {
                LastError = "Ошибка во время генерации ссылки! " + ex.ToString();
                return null;
            }
        }
        protected string _getCategoryName(int categoryId)
        {
            switch (categoryId)
            { 
                case 1:
                    return "Статьи";
                case 2:
                    return "Интервью";
                case 3:
                    return "Мнения";
                default:
                    return "?";
            }
        }
        #endregion
    }
}