﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Bankiru.Models.Domain.OrgsCategories
{
    public class VM_OrgCategory
    {
        [HiddenInput]
        public int Id { get; set; }
        [Display(Name = "Псевдоним")]
        public string Alias { get; set; }
        [Display(Name = "Название категории")]
        public string Title { get; set; }
    }
}