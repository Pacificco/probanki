﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Bankiru.Models.Domain.Users
{
    public class VM_UserItem
    {
        public int Id { get; set; }
        public int Name { get; set; }
        public int Nic { get; set; }
    }
}