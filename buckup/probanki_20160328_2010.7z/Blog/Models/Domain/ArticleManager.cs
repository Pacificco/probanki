﻿using Bankiru.Models.DataBase;
using Bankiru.Models.Domain.Comments;
using Bankiru.Models.Helpers;
using Bankiru.Models.Infrastructure;
using Bankiru.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Bankiru.Models.Domain
{
    /// <summary>
    /// Менеджер статей
    /// </summary>
    public class ArticleManager
    {
        /// <summary>
        /// Текст последней ошибки
        /// </summary>
        public string LastError { get; set; }

        #region СТАТЬИ
        /// <summary>
        /// Возвращает модель представления блога категории
        /// </summary>
        /// <param name="categoryId">Идентификатор категории</param>
        /// <param name="page">Старница</param>
        /// <returns></returns>
        public ArticleListVModel GetArticles(int categoryId, int page)
        {
            ArticleListVModel model = new ArticleListVModel();

            return model;
        }
        /// <summary>
        /// Возвращает модель представления статьи
        /// </summary>
        /// <param name="categoryId">Идентификатор статьи</param>
        /// <param name="page">Старница</param>
        /// <returns></returns>
        public ArticleListVModel GetArticles(string alias)
        {
            ArticleListVModel model = new ArticleListVModel();

            return model;
        }
        #endregion

        #region КАТЕГОРИИ
        /// <summary>
        /// Возвращает список представлений категорий
        /// </summary>
        /// <param name="useInMenu">Используются/не используются в меню</param>
        /// <param name="getEmpty">Пустые/не пустые категории</param>
        /// <param name="isActive">Активные/неактивные категории</param>
        /// <param name="loadArticleCount">Загружать количество статей в каждой категории</param>
        /// <returns>Список категорий</returns>
        public List<VM_Category> GetCategories(BoolType useInMenu, BoolType getEmpty,
            BoolType isActive, BoolType loadArticleCount)
        {
            List<VM_Category> _categories = new List<VM_Category>();
            string SqlQuery = String.Empty;
            SqlQuery += DbStruct.SE.SELECT + " ";
            SqlQuery += DbStruct.Categories.FIELDS.Id + ",";
            SqlQuery += DbStruct.Categories.FIELDS.Alias + ",";
            SqlQuery += DbStruct.Categories.FIELDS.Title + ",";
            SqlQuery += DbStruct.Categories.FIELDS.CDescription + ",";
            SqlQuery += DbStruct.Categories.FIELDS.IsActive;
            SqlQuery += " " + DbStruct.SE.FROM + " ";
            SqlQuery += DbStruct.Categories.TABLENAME;

            //Условия
            string SqlConditions = String.Empty;
            switch (isActive)
            { 
                case BoolType.True:
                    SqlConditions += " " + DbStruct.SE.AND + " ";
                    SqlConditions += DbStruct.Categories.FIELDS.IsActive + " = 1";
                    break;
                case BoolType.False:
                    SqlConditions += " " + DbStruct.SE.AND + " ";
                    SqlConditions += DbStruct.Categories.FIELDS.IsActive + " = 0";
                    break;
            }
            if (!String.IsNullOrEmpty(SqlConditions))
            {
                SqlQuery += " " + DbStruct.SE.WHERE + " ";
                SqlQuery += SqlConditions.Substring(5);
            }            
            SqlQuery += ";";
            if (String.IsNullOrEmpty(SqlQuery))
            {
                LastError = "Ошибка формирования запроса при получении списка категорий!";
                return null;
            }
            SqlCommand _command = null;
            SqlDataReader _reader = null;
            lock (GlobalParams._DBAccessLock)
            {
                try
                {
                    _command = new SqlCommand(SqlQuery, GlobalParams.GetConnection());
                    _reader = _command.ExecuteReader();
                    if (_reader != null && _reader.HasRows)
                    {
                        VM_Category cat = null;
                        while (_reader.Read())
                        {
                            cat = new VM_Category()
                            {
                                Id = _reader.GetInt32(0),
                                Alias = _reader.GetString(1),
                                Name = _reader.GetString(2),
                                Description = _reader.GetString(3),
                                IsActive = _reader.GetBoolean(4),
                                ArticlesCount = 0
                            };
                            _categories.Add(cat);
                        }
                    }
                }
                catch (Exception ex)
                {
                    LastError = "Ошибка во время загрузки категории из базы данных!\n" + ex.ToString();                    
                    return null;
                }
                finally
                {
                    if (_command != null)
                    {
                        _command.Dispose();
                    }
                    if (_reader != null)
                    {
                        _reader.Close();
                        _reader.Dispose();
                    }
                }
            }
            if (loadArticleCount == BoolType.True)
            {
                
            }
            return _categories;
        }
	    #endregion


        #region КОММЕНТАРИИ
        /// <summary>
        /// Возвращает список комментариев к статье с указанным идентификатором
        /// </summary>
        /// <param name="articleId">Идентификатор статьи</param>       
        /// <param name="lastAdded">Последние добавленные комментарии</param>
        /// <param name="count">Число комментариев</param>
        /// <returns>Список категорий</returns>
        public List<VM_Comment> GetComments(int articleId, bool lastAdded = true, int count = 5)
        {
            List<VM_Comment> _comments = new List<VM_Comment>();
            string SqlQuery = String.Empty;
            SqlQuery += DbStruct.SE.SELECT + " " + DbStruct.SE.TOP + " " + count.ToString() + " ";
            SqlQuery += DbStruct.Comments.ALIAS + "." + DbStruct.Comments.FIELDS.Id + ",";
            SqlQuery += DbStruct.Comments.ALIAS + "." + DbStruct.Comments.FIELDS.ArticleId + ",";
            SqlQuery += DbStruct.Comments.ALIAS + "." + DbStruct.Comments.FIELDS.Text + ",";
            SqlQuery += DbStruct.Comments.ALIAS + "." + DbStruct.Comments.FIELDS.CreatedAt + ",";
            SqlQuery += DbStruct.Users.ALIAS + "." + DbStruct.Users.FIELDS.Nic + ",";
            SqlQuery += DbStruct.Comments.ALIAS + "." + DbStruct.Comments.FIELDS.UserName;
            SqlQuery += " " + DbStruct.SE.FROM + " ";
            SqlQuery += DbStruct.Comments.TABLENAME + " " + DbStruct.Comments.ALIAS;
            SqlQuery += " " + DbStruct.SE.LEFT_JOIN + " ";
            SqlQuery += DbStruct.Users.TABLENAME + " " + DbStruct.Users.ALIAS;
            SqlQuery += " " + DbStruct.SE.ON + " ";
            SqlQuery += DbStruct.Users.ALIAS + "." + DbStruct.Users.FIELDS.Id;
            SqlQuery += " = ";
            SqlQuery += DbStruct.Comments.ALIAS + "." + DbStruct.Comments.FIELDS.UserId;

            //Условия
            string SqlConditions = String.Empty;
            if(articleId > 0)
            {
                SqlConditions += " " + DbStruct.SE.AND + " ";
                SqlConditions += DbStruct.Comments.ALIAS + "." + DbStruct.Comments.FIELDS.ArticleId;
                SqlConditions += " = " + articleId.ToString();
            }
            if (!String.IsNullOrEmpty(SqlConditions))
            {
                SqlQuery += " " + DbStruct.SE.WHERE + " ";
                SqlQuery += SqlConditions.Substring(5);
            }
            if (lastAdded)
            {
                SqlQuery += " " + DbStruct.SE.ORDER_BY + " ";
                SqlQuery += DbStruct.Comments.ALIAS + "." + DbStruct.Comments.FIELDS.CreatedAt;
                SqlQuery += " " + DbStruct.SE.DESC;
            }
            SqlQuery += ";";
            if (String.IsNullOrEmpty(SqlQuery))
            {
                LastError = "Ошибка формирования запроса при получении списка комментариев!";
                return null;
            }
            SqlCommand _command = null;
            SqlDataReader _reader = null;
            lock (GlobalParams._DBAccessLock)
            {
                try
                {
                    _command = new SqlCommand(SqlQuery, GlobalParams.GetConnection());
                    _reader = _command.ExecuteReader();
                    if (_reader != null && _reader.HasRows)
                    {
                        VM_Comment com = null;
                        while (_reader.Read())
                        {
                            com = new VM_Comment()
                            {
                                //Id = _reader.GetInt32(0),
                                //ArticleId = _reader.GetInt32(1),
                                //Text = _reader.GetString(2),                                                                
                                //CreatedAt = _reader.GetDateTime(3),                                
                                //Author = _reader.IsDBNull(4) ? _reader.GetString(5) : _reader.GetString(4),
                                //Beds = 0,
                                //Likes = 0
                            };
                            _comments.Add(com);
                        }
                    }
                }
                catch (Exception ex)
                {
                    LastError = "Ошибка во время загрузки комментариев из базы данных!\n" + ex.ToString();
                    return null;
                }
                finally
                {
                    if (_command != null)
                    {
                        _command.Dispose();
                    }
                    if (_reader != null)
                    {
                        _reader.Close();
                        _reader.Dispose();
                    }
                }
            }
            return _comments;
        }
        #endregion
    }
}