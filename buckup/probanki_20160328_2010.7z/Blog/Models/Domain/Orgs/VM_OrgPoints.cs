﻿using Bankiru.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Bankiru.Models.Domain.Orgs
{
    public class VM_OrgPoints
    {
        public VM_OrgItem Org { get; set; }
        public VM_OrgsPointsFilters Filters { get; set; }
        public List<VM_OrgPoint> Items { get; set; }
        public VM_PagingInfo PagingInfo { get; set; }

        public VM_OrgPoints()
        {
            Org = new VM_OrgItem();
            Filters = new VM_OrgsPointsFilters();
            Items = new List<VM_OrgPoint>();
            PagingInfo = new VM_PagingInfo();
        }
    }
}