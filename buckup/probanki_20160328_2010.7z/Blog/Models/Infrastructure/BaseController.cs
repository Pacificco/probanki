﻿using Bankiru.Models.Domain;
using Bankiru.Models.Domain.Account;
using Bankiru.Models.Domain.Articles;
using Bankiru.Models.Domain.Comments;
using Bankiru.Models.Domain.News;
using Bankiru.Models.Domain.Orgs;
using Bankiru.Models.Domain.Other;
using Bankiru.Models.Helpers;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Bankiru.Models.Infrastructure
{
    public abstract class BaseController : Controller
    {
        /// <summary>
        /// Подключение
        /// </summary>
        protected SqlConnection _connection;
        /// <summary>
        /// Подключение установлено
        /// </summary>
        protected bool _connected;

        /// <summary>
        /// Сообщение об ошибках
        /// </summary>
        protected string _errMassage;
        /// <summary>
        /// Предупреждение
        /// </summary>
        protected string _warningMassage;
        /// <summary>
        /// Сообщение
        /// </summary>
        protected string _infoMassage;

        /// <summary>
        /// Страница с ошибкой
        /// </summary>
        protected string _errPage;
        /// <summary>
        /// Страница с ошибкой для частичных представлений
        /// </summary>
        protected string _errPartialPage;


        public BaseController()
            : base()
        {
            _connection = null;
            _connected = false;

            _errMassage = String.Empty;
            _warningMassage = String.Empty;
            _infoMassage = String.Empty;

            _errPage = "~/Views/Shared/Error.cshtml";
            _errPartialPage = "~/Views/Shared/PartialError.cshtml";

            //AccountManager _manager = new AccountManager();
            //string password = _manager._getMd5Hash("SupperPassword");
            //if (password == "111") return;

            Connect();
        }

        /// <summary>
        /// Подключается к базе данных
        /// </summary>
        private void Connect()
        {
            try
            {
                _connection = GlobalParams.GetConnection();
                if (_connection == null)
                {
                    _errMassage = GlobalParams._connectionError;
                    _connected = false;
                }
                else
                {
                    _connected = true;
                }                
            }
            catch (Exception e)
            {
                _errMassage = e.ToString();
                _connected = false;
            }
        }

        #region СПИСКИ
        [ChildActionOnly]
        public ActionResult _getOrgsDropDownList(int selectedId, EnumFirstDropDownItem firstItem, string id)
        {
            try
            {
                if (_connected)
                {
                    OrgsManager _manager = new OrgsManager();
                    VM_DropDownOrgItems model = new VM_DropDownOrgItems();
                    model.SelectedId = selectedId;
                    model.Items = _manager.GetOrgItems();
                    model.FirstItem = firstItem;
                    model.Name = id;
                    return PartialView("_orgsDropDownList", model);
                }
                else
                {
                    ViewBag.ErrorMessage = _errMassage;
                    return PartialView(_errPartialPage);
                }
            }
            catch (Exception e)
            {
                ViewBag.ErrorMessage = e.ToString();
                return PartialView(_errPartialPage);
            }
        }
        [ChildActionOnly]
        public ActionResult _getRegionsDropDownList(Guid selectedId, EnumFirstDropDownItem firstItem, string id)
        {
            try
            {
                if (_connected)
                {
                    VM_DropDownRegions model = new VM_DropDownRegions();
                    model.SelectedId = selectedId;
                    model.Items = DbHelper.GetRegions();
                    model.FirstItem = firstItem;
                    model.Name = id;
                    return PartialView("_regionsDropDownList", model);
                }
                else
                {
                    ViewBag.ErrorMessage = _errMassage;
                    return PartialView(_errPartialPage);
                }
            }
            catch (Exception e)
            {
                ViewBag.ErrorMessage = e.ToString();
                return PartialView(_errPartialPage);
            }
        }
        [ChildActionOnly]
        public ActionResult _getOrgCategoriesDropDownList(int selectedId, EnumFirstDropDownItem firstItem, string id)
        {
            try
            {
                if (_connected)
                {
                    OrgsManager _manager = new OrgsManager();
                    VM_DropDownOrgCategories model = new VM_DropDownOrgCategories();
                    model.SelectedId = selectedId;
                    model.Items = _manager.GetOrgCategories();
                    model.FirstItem = firstItem;
                    model.Name = id;
                    return PartialView("_orgCategoriesDropDownList", model);
                }
                else
                {
                    ViewBag.ErrorMessage = _errMassage;
                    return PartialView(_errPartialPage);
                }
            }
            catch (Exception e)
            {
                ViewBag.ErrorMessage = e.ToString();
                return PartialView(_errPartialPage);
            }
        }
        [ChildActionOnly]
        public ActionResult _getCategoriesDropDownList(int selectedId, EnumFirstDropDownItem firstItem, string id)
        {
            try
            {
                if (_connected)
                {
                    ArtsManager _manager = new ArtsManager();
                    VM_DropDownCategories model = new VM_DropDownCategories();
                    model.SelectedId = selectedId;
                    model.Items = _manager.GetCategories();
                    model.FirstItem = firstItem;
                    model.Name = id;
                    return PartialView("_categoriesDropDownList", model);
                }
                else
                {
                    ViewBag.ErrorMessage = _errMassage;
                    return PartialView(_errPartialPage);
                }
            }
            catch (Exception e)
            {
                ViewBag.ErrorMessage = e.ToString();
                return PartialView(_errPartialPage);
            }
        }
        [ChildActionOnly]        
        public ActionResult _getActiveDropDownList(EnumBoolType selectedId, EnumFirstDropDownItem firstItem, string id)
        {
            try
            {
                VM_DropDownActive model = new VM_DropDownActive();
                model.FirstItem = firstItem;
                model.Name = id;
                model.SelectedId = selectedId;
                return PartialView("_activeDropDownList", model);                
            }
            catch (Exception e)
            {
                ViewBag.ErrorMessage = e.ToString();
                return PartialView(_errPartialPage);
            }
        }
        [ChildActionOnly]
        public ActionResult _getOrgPointTypesDropDownList(int selectedId, EnumFirstDropDownItem firstItem, string id)
        {
            try
            {
                if (_connected)
                {
                    VM_DropDownOrgPointTypes model = new VM_DropDownOrgPointTypes();
                    model.SelectedId = selectedId;
                    model.Items = new List<string>();
                    model.Items.Add("Офисы");
                    model.Items.Add("Банкоматы");
                    model.FirstItem = firstItem;
                    model.Name = id;
                    return PartialView("_orgPointTypesDropDownList", model);
                }
                else
                {
                    ViewBag.ErrorMessage = _errMassage;
                    return PartialView(_errPartialPage);
                }
            }
            catch (Exception e)
            {
                ViewBag.ErrorMessage = e.ToString();
                return PartialView(_errPartialPage);
            }
        }
        #endregion

        #region МОДУЛИ
        [ChildActionOnly]
        public ActionResult _getModuleOrgMenu(string current_item = "")
        {
            try
            {
                return PartialView("_moduleOrgMenu", current_item);
            }
            catch (Exception e)
            {
                ViewBag.ErrorMessage = e.ToString();
                return PartialView(_errPartialPage);
            }
        }
        [ChildActionOnly]
        public ActionResult _getModuleLastComment(int categoryId = 0, int row_count = 5)
        {
            try
            {
                if (_connected)
                {               
                    ArtsManager manager = new ArtsManager();
                    VM_Comments model = manager.GetLastComments(categoryId, row_count);
                    if (model != null)
                    {
                        return PartialView("_moduleLastComments", model);
                    }
                    else
                    {
                        ViewBag.ErrorMessage = manager.LastError;
                        return PartialView(_errPartialPage);
                    }
                }
                else
                {
                    ViewBag.ErrorMessage = _errMassage;
                    return PartialView(_errPartialPage);
                }
            }
            catch (Exception e)
            {
                ViewBag.ErrorMessage = e.ToString();
                return PartialView(_errPartialPage);
            }
        }
        [ChildActionOnly]
        public ActionResult _getModuleLastNews(int row_count = 10)
        {
            try
            {
                if (_connected)
                {
                    NewsManager manager = new NewsManager();
                    List<VM_NewsItem> model = manager.GetLastNews(row_count);
                    if (model != null)
                    {
                        return PartialView("_moduleLastNews", model);
                    }
                    else
                    {
                        ViewBag.ErrorMessage = manager.LastError;
                        return PartialView(_errPartialPage);
                    }                    
                }
                else
                {
                    ViewBag.ErrorMessage = _errMassage;
                    return PartialView(_errPartialPage);
                }
            }
            catch (Exception e)
            {
                ViewBag.ErrorMessage = e.ToString();
                return PartialView(_errPartialPage);
            }
        }
        [ChildActionOnly]
        public ActionResult _getModuleLastPopularOrgs(int row_count)
        {
            try
            {
                if (_connected)
                {
                    return PartialView("_modulePopularOrgs", null);
                }
                else
                {
                    ViewBag.ErrorMessage = _errMassage;
                    return PartialView(_errPartialPage);
                }
            }
            catch (Exception e)
            {
                ViewBag.ErrorMessage = e.ToString();
                return PartialView(_errPartialPage);
            }
        }
        [ChildActionOnly]
        public ActionResult _getModuleLastReviews(int row_count)
        {
            try
            {
                if (_connected)
                {
                    return PartialView("_moduleLastReviews", null);
                }
                else
                {
                    ViewBag.ErrorMessage = _errMassage;
                    return PartialView(_errPartialPage);
                }
            }
            catch (Exception e)
            {
                ViewBag.ErrorMessage = e.ToString();
                return PartialView(_errPartialPage);
            }
        }
        #endregion
    }
}