﻿using System.Web.Mvc;

namespace Bankiru.Areas.Admin
{
    public class AdminAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "Admin";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                name: "admin_org_points",
                url: "Admin/Orgs/{org_id}/Points/{action}/{id}",
                defaults: new { controller = "Orgs", action = "PointsList", org_id = UrlParameter.Optional, id = UrlParameter.Optional },
                namespaces: new[] { "Bankiru.Areas.Admin.Controllers" }
            );
            context.MapRoute(
                name: "admin_orgs",
                url: "Admin/Orgs/{action}/{id}",
                defaults: new { controller = "Orgs", action = "List", id = UrlParameter.Optional },
                namespaces: new[] { "Bankiru.Areas.Admin.Controllers" }
            );
            context.MapRoute(
                name: "admin_articles",
                url: "Admin/Articles/{action}/{id}",
                defaults: new { controller = "Articles", action = "List", id = UrlParameter.Optional },
                namespaces: new[] { "Bankiru.Areas.Admin.Controllers" }
            );
            context.MapRoute(
                name: "admin_comments",
                url: "Admin/Comments/{action}/{id}",
                defaults: new { controller = "Comments", action = "List", id = UrlParameter.Optional },
                namespaces: new[] { "Bankiru.Areas.Admin.Controllers" }
            );
            context.MapRoute(
                name: "admin_news",
                url: "Admin/News/{action}/{id}",
                defaults: new { controller = "News", action = "List", id = UrlParameter.Optional },
                namespaces: new[] { "Bankiru.Areas.Admin.Controllers" }
            );
            context.MapRoute(
                name: "admin_rewiews",
                url: "Admin/Rewiews/{action}/{id}",
                defaults: new { controller = "Rewiews", action = "List", id = UrlParameter.Optional },
                namespaces: new[] { "Bankiru.Areas.Admin.Controllers" }
            );
            context.MapRoute(
                name: "admin_default",
                url: "Admin/{controller}/{action}/{id}",
                defaults: new { controller = "Info", action = "Index", id = UrlParameter.Optional },
                namespaces: new[] { "Bankiru.Areas.Admin.Controllers" }
            );
        }
    }
}
