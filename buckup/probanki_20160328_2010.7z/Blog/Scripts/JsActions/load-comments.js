﻿$()
{
    $('#ajaz-link').click();
}