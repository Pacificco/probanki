﻿using Bankiru.Models.Domain.Articles;
using Bankiru.Models.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Bankiru.Models.ViewModels.Articles;

namespace Bankiru.Controllers
{
    public class HomeController : BaseController
    {

        public ActionResult Index()
        {
            try
            {
                if (_connected)
                {
                    ArtsManager _manager = new ArtsManager();
                    VM_ArtItem model = _manager.GetCentralArtItem();
                    return View(model);
                    //if (model != null)
                    //{                        
                    //    return View(model);
                    //}
                    //else
                    //{
                    //    ViewBag.ErrorMessage = _manager.LastError;
                    //    return View(_errPage);
                    //}
                }
                else
                {
                    ViewBag.ErrorMessage = _errMassage;
                    return View(_errPage);
                }
            }
            catch (Exception e)
            {
                ViewBag.ErrorMessage = e.ToString();
                return View(_errPage);
            }
        }

        public ActionResult Feedback()
        {
            return View();
        }
    }
}
