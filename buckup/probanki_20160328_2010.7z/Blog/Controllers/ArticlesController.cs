﻿using Bankiru.Models.Domain;
using Bankiru.Models.Domain.Comments;
using Bankiru.Models.Helpers;
using Bankiru.Models.Infrastructure;
using Bankiru.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Bankiru.Controllers
{
    public class ArticlesController : BaseController
    {
        [HttpGet]
        public ActionResult Blog(int categoryId, int page = 1)
        {
            try
            {
                if (_connected)
                {
                    ArticleManager _menage = new ArticleManager();
                    if (categoryId < 1)
                    {
                        return HttpNotFound("Такой страницы не существует");
                    }
                    ArticleListVModel model = _menage.GetArticles(categoryId, page);
                    if (model != null)
                    {
                        return View(model);
                    }
                    else
                    {
                        ViewBag.ErrorMessage = _menage.LastError;
                        return View(_errPage);
                    }
                }
                else
                {
                    ViewBag.ErrorMessage = _errMassage;
                    return View(_errPage);
                }
            }
            catch (Exception e)
            {
                ViewBag.ErrorMessage = e.ToString();
                return View(_errPage);
            }
        }
        [HttpGet]
        public ActionResult Article(int id)
        {
            return View();
        }
        [HttpGet]
        public ActionResult Comment(int id)
        {
            return View();
        }

        [HttpGet]
        public ActionResult PartialCategoriesMenu()
        {
            try
            {
                if (_connected)
                {
                    ArticleManager _manager = new ArticleManager();
                    List<VM_Category> _categories = _manager.GetCategories(BoolType.Empty, BoolType.Empty, BoolType.Empty, BoolType.Empty);
                    if (_categories == null)
                    {
                        ViewBag.ErrorMessage = _manager.LastError;
                        return PartialView(_errPartialPage);
                    }
                    return PartialView("_categoriesMenu", _categories);
                }
                else
                {
                    ViewBag.ErrorMessage = _errMassage;
                    return PartialView(_errPartialPage);
                }
            }
            catch (Exception e)
            {
                ViewBag.ErrorMessage = e.ToString();
                return PartialView(_errPartialPage);
            }
        }
        [HttpGet]
        public ActionResult PartialCommentsList(int id)
        {
            try
            {
                if (_connected)
                {
                    ArticleManager _manager = new ArticleManager();
                    List<VM_Comment> _comments = _manager.GetComments(id);
                    if (_comments == null)
                    {
                        ViewBag.ErrorMessage = _manager.LastError;
                        return PartialView(_errPartialPage);
                    }
                    return PartialView("_commentsList", _comments);
                }
                else
                {
                    ViewBag.ErrorMessage = _errMassage;
                    return PartialView(_errPartialPage);
                }
            }
            catch (Exception e)
            {
                ViewBag.ErrorMessage = e.ToString();
                return PartialView(_errPartialPage);
            }
        }
    }
}
